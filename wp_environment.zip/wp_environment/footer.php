<!-- Footer -->
<!-- code  -->


    <?php wp_footer(); ?>
</body>

</html>
